# CVWerk Schweiz — Netlify site

## Pages
- `/` German homepage
- `/ru/` Russian homepage
- `/uk/` Ukrainian homepage
- `/lebenslauf/`, `/bewerbungsschreiben/`, `/preise/`
- `/datenschutz/`, `/impressum/` — incomplete legal templates
- Netlify contact form and `/danke/` thank-you page

## Before launch
1. Replace every `YOUR-SITE.netlify.app` with the actual Netlify subdomain in canonical links and SEO files.
2. Edit `assets/site.js`: add a verified email and WhatsApp number. Do not add guessed contact details.
3. Complete and review the legal pages with actual operator details and a real privacy notice. Do not publish the current placeholders unchanged.
4. Confirm the proposed introductory prices (CHF 29 / 49 / 79) and service scope.
5. Upload the project contents to Netlify using **Add new site → Deploy manually**, or connect a Git repository with publish directory `.`.
6. In Netlify site settings, enable form detection if required and redeploy. Confirm `cvwerk-contact` appears in Forms.
7. Configure a form notification to a verified email address in the Netlify dashboard and submit a test request.
8. Replace placeholder site URL in sitemap.xml, robots.txt and canonical/hreflang URLs.
9. Add the site to Google Search Console, verify ownership and submit `/sitemap.xml`.

## Important
- `YOUR-SITE.netlify.app` is a placeholder, not a live URL.
- Contact email and WhatsApp are intentionally blank until confirmed.
- The form requires Netlify Forms detection to be enabled and tested.
- Privacy/Impressum pages are templates and must be completed before public launch.
- Do not collect sensitive identity or banking information through the first contact form.
