const CVWERK_CONFIG={siteUrl:"https://inspiring-lollipop-c8e756.netlify.app",email:"burcev9292@gmail.com",whatsappNumber:"41767985612"};document.querySelectorAll("[data-year]").forEach(e=>e.textContent=new Date().getFullYear());document.querySelectorAll(".email-link").forEach(a=>{if(CVWERK_CONFIG.email)a.href="mailto:"+CVWERK_CONFIG.email+"?subject="+encodeURIComponent("Anfrage an CVWerk Schweiz");else a.href="#kontakt"});document.querySelectorAll(".whatsapp-link").forEach(a=>{if(CVWERK_CONFIG.whatsappNumber){a.href="https://wa.me/"+CVWERK_CONFIG.whatsappNumber;a.hidden=false;a.target="_blank";a.rel="noopener noreferrer"}});document.querySelectorAll("[data-package]").forEach(a=>a.addEventListener("click",()=>{let p=document.querySelector("#package");if(p)p.value=a.dataset.package;document.querySelectorAll(".price-card").forEach(card=>card.classList.remove("selected"));a.closest(".price-card")?.classList.add("selected")}));
// Keep FormSubmit as the form endpoint and select the thank-you page by language.
document.querySelectorAll('form[name="cvwerk-contact"]').forEach(form=>{
  form.method="POST";
  form.action="https://formsubmit.co/burcev9292@gmail.com";
  form.addEventListener("submit",()=>{
    const language=form.querySelector('select[name="language"]');
    const selected=(language?.selectedOptions?.[0]?.textContent||"").trim().toLowerCase();
    const next=form.querySelector('input[name="_next"]');
    if(!next)return;
    if(selected.includes("рус") || selected.includes("рос")) next.value="https://andrii9292.github.io/cvwerk-schweiz/ru/danke/";
    else if(selected.includes("укра")) next.value="https://andrii9292.github.io/cvwerk-schweiz/uk/danke/";
    else next.value="https://andrii9292.github.io/cvwerk-schweiz/danke/";
  });
});

// Compact the sticky header after scrolling and animate content as it enters view.
(()=>{
  const header=document.querySelector('.nav');
  const updateHeader=()=>header?.classList.toggle('is-scrolled',window.scrollY>12);
  updateHeader();
  window.addEventListener('scroll',updateHeader,{passive:true});

  const reducedMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  if(reducedMotion||!('IntersectionObserver' in window))return;
  const targets=document.querySelectorAll('.hero > div, .section .head, .grid3 > *, .steps > div, .contact-layout > *');
  if(!targets.length)return;
  document.documentElement.classList.add('js-reveal');
  const observer=new IntersectionObserver((entries,obs)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){entry.target.classList.add('is-visible');obs.unobserve(entry.target)}
    });
  },{threshold:.12,rootMargin:'0px 0px -35px 0px'});
  targets.forEach((el,index)=>{
    el.classList.add('reveal');
    if(el.matches('.grid3 > *'))el.classList.add('reveal-delay-'+((index%3)+1));
    observer.observe(el);
  });
})();
